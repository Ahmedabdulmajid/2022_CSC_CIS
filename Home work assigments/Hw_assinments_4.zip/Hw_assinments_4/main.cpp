/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Ahmed Ibrahim
 *
 * Created on June 26, 2022, 5:45 PM
 */
/*
 Q-4
 * Write a program that inputs a character from the keyboard and then 
outputs a large block letter “C” composed of that character. For example, 
if the user inputs the character “X,” then the output should look as 
follows:
 X X X
 X X
 X
 X
 X
 X
 X
 X X
 X X X
 */

#include <iostream>

using namespace std;

int main(int argc, char** argv) {
    cout << " X X X\n";
cout << " X X\n";
cout << "X\n";
cout << "X\n";
cout << "X\n";
cout << "X\n";
cout << "X\n";
cout << " X X\n";
cout << " X X X\n";

    return 0;
}

